const client = (() => {
    let serviceWorker = undefined;
    const notificationbutton = document.getElementById("btn-notify");

    const showNotificationButton = () => {
        notificationbutton.style.display = "block";
    }

    const checkNotificationSupport = () => {
        if(!('Notification' in window)){
            return Promise.reject("This Browser doesn't support notifications")
        }
        console.log("The browser support Notifications")
        return Promise.resolve("ok!")
    }

    const registerServiceWorker = () => {
        if(!('serviceWorker') in navigator) {
           return Promise.reject("service worker is not available")
    }
    
    return navigator.serviceWorker.register('service-worker.js')
    .then(regObj => {
        console.log("service worker is registered successfully");
        serviceWorkerRegObj = regObj;
        showNotificationButton();
    })
  }

  const requestNotificationPermissions = () => {
    return Notification.requestPermission(status => {
        console.log("Notifications Permission Status:", status);
    })
  }
    //How the contstructors are called
    checkNotificationSupport()
        .then(registerServiceWorker)
        .then(requestNotificationPermissions)
        .catch(err => console.error(err))
})()