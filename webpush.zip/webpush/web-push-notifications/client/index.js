const client = (() => {
    let serviceWorker = undefined;
    const notificationbutton = document.getElementById("btn-notify");

    const showNotificationButton = () => {
        notificationbutton.style.display = "block";
        notificationbutton.addEventListener("click", showNotification);
    }

    const showNotification = () => {

        //console.log("button clicked");
        const simpleTextNotification = reg => reg.showNotification("First Notification")

        const customizedNotification = reg => {
            const options = {
                body: 'Spring Semester is almost completed!',
                icon: "imgs/notification.png",
                actions: [
                    {action: "search", title: "Search Point Park"},
                    {action: "close", title: "Nevermind"},
                ],
                data: {
                    notificationTime: Date.now(),
                    githubUser: "jeffreyjseamanppu"
                }
            }
            reg.showNotification('Second Notification', options)
        }
        navigator.serviceWorker.getRegistration()
        .then(registration => customizedNotification(registration));
        //.then(registration => registration.showNotification("First Notification"));
    }

    //1st part, after running first time, then modify code
    /*
    const checkNotificationSupport = () => {
        return Promise.reject("notification support not checked.")
    }
    */

    //2nd iteration
    const checkNotificationSupport = () => {
        if(!('Notification' in window)){
            return Promise.reject("This browser doesn't support notifications.") 
        }
        console.log("The browser support Notifications")
        return Promise.resolve("Ok!")
    }
    //1st iteration
    /*
    const registerServiceWorker = () => {
        return Promise.reject("service worker not registered yet")
    }
    */

    //2nd Iteration
    const registerServiceWorker = () => {
        if(!('serviceWorker') in navigator) {
            return Promise.reject("service worker is not available")
        }

        return navigator.serviceWorker.register('service-worker.js')
        .then(regObj => {
            console.log("service worker is registered successfully!");
            serviceWorkerRegObj = regObj;
            showNotificationButton();
        })
    }

    const requestNotificationPermissions = () => {
        //return Promise.reject("Permissions not requested.")
        //second iteration
        return Notification.requestPermission(status => {
            console.log("Notifications Permission Status:", status);
        })
    }

    checkNotificationSupport()
        .then(registerServiceWorker)
        .then(requestNotificationPermissions) //add after const requestNotificationsPermissions
        .catch(err => console.error(err))
})()